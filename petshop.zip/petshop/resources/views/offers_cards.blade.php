<!-- offers-cards --> 
	<div class="w3single-offers offer-bottom"> 
		<div class="col-md-6 offer-bottom-grids">
			<div class="offer-bottom-grids-info2">
				<h4>Special Gift Cards</h4> 
				<h6>More brands, more ways to shop. <br> Check out these ideal gifts!</h6>
			</div>
		</div>
		<div class="col-md-6 offer-bottom-grids">
			<div class="offer-bottom-grids-info">
				<h4>Flat $10 Discount</h4> 
				<h6>The best Shopping Offer <br> On Fashion Store</h6>
			</div>
		</div>
		<div class="clearfix"> </div>
	</div>
	<!-- //offers-cards -->